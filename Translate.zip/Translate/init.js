function reloadSubtitles() {
    window.setTimeout(() => {
        var ccButton = document.getElementsByClassName("ytp-subtitles-button")[0];
        ccButton.click();
        ccButton.click();
    }, 1000);
}

chrome.storage.onChanged.addListener(async function() {
    console.log("initialising filter rules, settings changed");
    chrome.storage.sync.get(['translationActive', 'destinationLanguage'], async function (settings) {
        chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [1]
        });

        if(!!settings.translationActive) {
            chrome.declarativeNetRequest.updateDynamicRules({
                addRules: [
                    {
                        id: 1,
                        priority: 1,
                        action: {
                            type: "redirect",
                            "redirect": {
                                "transform": {
                                    "queryTransform": {
                                        "addOrReplaceParams": [
                                            {"key": "tlang", "value": settings.destinationLanguage}
                                        ]
                                    }
                                }
                            }
                        },
                        "condition": {
                            "urlFilter": "api/timedtext",
                            "domains": [
                                "youtube.com"
                            ],
                            "resourceTypes": [
                                "xmlhttprequest"
                            ]
                        }
                    },
                ],
            });
        }
        let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        chrome.scripting.executeScript({
            target: {tabId: tab.id},
            function: reloadSubtitles
        })
    });
});