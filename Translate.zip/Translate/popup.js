function initialisePopup() {
    chrome.storage.sync.get(['translationActive', 'destinationLanguage'], function (settings) {
        console.log("Saving settings to storage...");
        document.getElementById('destinationLanguageSelect').value = settings.destinationLanguage;
        document.getElementById('translationActiveToggleButton').checked = settings.translationActive
    });
}

initialisePopup();

chrome.storage.onChanged.addListener(function() {
    console.log("initialising popup, settings changed");
    initialisePopup();
});

document.getElementById('translationActiveToggleButton').addEventListener('change', (event) => {
    chrome.storage.sync.get(['translationActive'], function (setting) {
        chrome.storage.sync.set({translationActive: event.target.checked}, function () {});
    });
});

document.getElementById('destinationLanguageSelect').onchange = function() {
    var language = this.selectedIndex ? this.options[this.selectedIndex].value : 'nl';
    chrome.storage.sync.set({'destinationLanguage': language}, function () {});
};
